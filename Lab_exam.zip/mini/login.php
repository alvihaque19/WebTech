<?php

session_start();
session_destroy();
session_start();

if($_SERVER['REQUEST_METHOD']=='POST'){
	
	$servername = 'localhost';
	$username = 'root';
	$password = '';
	$dbname = 'webtec';
	
	$conn = mysqli_connect($servername,$username,$password,$dbname);
	
	if(!$conn){
		echo "not connected";
	}
	
	$id = $_POST['id'];
	$pass = $_POST['pass'];
	
	
	$sql = "select id,password,type from users where id=".$id." and password='".$pass."'";
	
	
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_assoc($result);
	

	
	if(count($row)>0 && $row['type']=='admin'){
		$_SESSION['id']=$id;
		$_SESSION['password']=$pass;
		$_SESSION['type']= 'admin';
		header('location: admin_home.php');
	}
	else if(count($row)>0 && $row['type']=='user'){
		$_SESSION['id']=$id;
		$_SESSION['password']=$pass;
		$_SESSION['type']= 'admin';
		header('location: user_home.php');
	}
	else{
		echo "information not correct";
	}
	
	
	
	
	
}






 ?>




<center>
<form action="login.php" method="POST">
	<table border="0" cellspacing="0" cellpadding="0">
		<tr>
			<td>
				<fieldset>
					<legend><h3>LOGIN</h3></legend>
					User Id<br/>
					<input name="id" value="" type="text" required><br/>                               
					Password<br/>
					<input name="pass" value="" type="password" required>
					<br /><hr/>
					<input type="submit" value="Login">
					<a href="registration.php">Register</a>
				</fieldset>
			</td>
		</tr>                                
	</table>
</form>
</center>