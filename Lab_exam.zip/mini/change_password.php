<?php

    session_start();
	
	
	
    $servername = 'localhost';
	$username = 'root';
	$password = '';
	$dbname = 'webtec';
	
	$conn = mysqli_connect($servername,$username,$password,$dbname);
	
	if(!$conn){
		echo "not connected";
	}
	
	$id = $_SESSION['id'];
	$pass = $_SESSION['password'];
	$type = $_SESSION['type'];
	
	
	$sql = "select id,password,type from users where id=".$id." and password='".$pass."'";
	
	
	$result = mysqli_query($conn,$sql);
	$row = mysqli_fetch_assoc($result);
	
	if(count($row)>0){
		
		echo '<center>
	<form action="change_password.php" method="POST">
		<table border="0" cellspacing="0" cellpadding="5">
			<tr>
				<td>
					<fieldset>
						<legend>CHANGE PASSWORD</legend>
						Current Password<br />
						<input name="passC" type="password" /><br /><?php echo $err1 ?>
						New Password<br />
						<input name="passN" type="password" /><br />
						Retype New Password<br />
						<input name="passR" type="password"/><?php echo $err2 ?>								
						<hr />
						<input type="submit" value="Change" />';

		if($row['type']=='user'){
			echo '<a href="user_home.php">Home</a>						
					</fieldset>
				</td>
			</tr>
		</table>
	</form>
</center>';
		}
		else{
			
			
			echo '<a href="admin_home.php">Home</a>						
					</fieldset>
				</td>
			</tr>
		</table>
	</form>
</center>';
			
		}
						
	}
	else{
		echo "you are not permitted to access this page"."<h1>LOGIN FIRST</H1>";
	}
	
	$err1 = '';
	$err2 = '';
	
	if($_SERVER['REQUEST_METHOD']=='POST'){
		
		
		$passC = $_POST['passC'];
		$passN = $_POST['passN'];
		$passR = $_POST['passR'];
		
		$is_err = 0;
	
		
		if($passC!=$pass){
			$err1 = "current password not match";
			$is_err = 1;
		}
		if($passN != $passR){
			$err2 = "new and confirm password not match";
			$is_err= 1;
		}
		
		if($is_err == 0){
			
			$sql = "update users set password='".$passN."' where id = ".$id."";
			mysqli_query($conn,$sql);
			echo "password updated successfully!!!";
			
		}
		else{
			echo "information not correct";
		}
		
		
		
	}
	
	
	
	
	
	
 ?>









